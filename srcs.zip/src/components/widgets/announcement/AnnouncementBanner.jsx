import { useWidgetData } from "../../../hooks/useWidgetData";
import { widgetRegistry } from "../registry";
import { useWidgetStore } from "../../../store/widgetStore";

function AnnouncementBanner({ settings }) {
  const { items, loading, error } = useWidgetData(settings.api?.url);

  const layoutConfig = widgetRegistry.announcement.layouts[settings.layout];
  const LayoutComponent = layoutConfig?.component;

  const visibleItems = items.slice(0, Number(settings.items_num));

  if (loading) {
    return <div className="ghl-widget-status">Loading…</div>;
  }

  if (error) {
    return <div className="ghl-widget-status">Couldn't load data: {error}</div>;
  }

  if (!LayoutComponent) {
    return (
      <div className="ghl-widget-status">Unknown layout: {settings.layout}</div>
    );
  }

  return (
    <div>
      <LayoutComponent items={visibleItems} />
    </div>
  );
}

export default AnnouncementBanner;
